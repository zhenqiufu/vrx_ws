This implements
[Algorithms for Geodesics](https://doi.org/10.1007/s00190-012-0578-z)
(Karney, 2013) for solving the direct and inverse problems for an
ellipsoid of revolution.

Documentation is available at
<https://geographiclib.sourceforge.io/1.50/python/>.
