GeographicLib
=============

A C++ library for geographic projections.  The web site for the package
is

> https://geographiclib.sourceforge.io

The API for the library is documented at

> https://geographiclib.sourceforge.io/html
